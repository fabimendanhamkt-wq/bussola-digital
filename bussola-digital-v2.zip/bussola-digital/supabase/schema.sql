-- ============================================================
-- BÚSSOLA DIGITAL® — Schema Supabase
-- Executar no SQL Editor do painel Supabase
-- ============================================================

-- Habilitar RLS globalmente
alter default privileges in schema public
  grant all on tables to postgres, anon, authenticated, service_role;

-- ────────────────────────────────────────────
-- Tabela: profiles
-- Extensão da tabela auth.users
-- ────────────────────────────────────────────
create table if not exists public.profiles (
  id          uuid references auth.users(id) on delete cascade primary key,
  full_name   text,
  email       text,
  created_at  timestamptz default now()
);

alter table public.profiles enable row level security;

create policy "Usuário vê apenas o próprio perfil"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Usuário atualiza apenas o próprio perfil"
  on public.profiles for update
  using (auth.uid() = id);

-- Trigger: cria perfil automaticamente ao registrar
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name, email)
  values (new.id, new.raw_user_meta_data->>'full_name', new.email);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ────────────────────────────────────────────
-- Tabela: sessions (trabalhos salvos)
-- Um "trabalho" = uma conversa iniciada com um assistente
-- ────────────────────────────────────────────
create table if not exists public.sessions (
  id          uuid default gen_random_uuid() primary key,
  user_id     uuid references auth.users(id) on delete cascade not null,
  assistant   text not null check (assistant in ('clara','bia','caio','nina')),
  title       text not null default 'Novo trabalho',
  status      text not null default 'active' check (status in ('active','completed','archived')),
  input_data  jsonb default '{}'::jsonb,
  output_data jsonb default '{}'::jsonb,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

alter table public.sessions enable row level security;

create policy "Usuário vê apenas os próprios trabalhos"
  on public.sessions for select
  using (auth.uid() = user_id);

create policy "Usuário cria seus trabalhos"
  on public.sessions for insert
  with check (auth.uid() = user_id);

create policy "Usuário atualiza seus trabalhos"
  on public.sessions for update
  using (auth.uid() = user_id);

create policy "Usuário exclui seus trabalhos"
  on public.sessions for delete
  using (auth.uid() = user_id);

-- Trigger: atualiza updated_at
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger sessions_updated_at
  before update on public.sessions
  for each row execute procedure public.touch_updated_at();

-- ────────────────────────────────────────────
-- Tabela: messages (histórico de conversa)
-- ────────────────────────────────────────────
create table if not exists public.messages (
  id          uuid default gen_random_uuid() primary key,
  session_id  uuid references public.sessions(id) on delete cascade not null,
  user_id     uuid references auth.users(id) on delete cascade not null,
  role        text not null check (role in ('user','assistant')),
  content     text not null,
  created_at  timestamptz default now()
);

alter table public.messages enable row level security;

create policy "Usuário vê apenas as próprias mensagens"
  on public.messages for select
  using (auth.uid() = user_id);

create policy "Usuário insere apenas as próprias mensagens"
  on public.messages for insert
  with check (auth.uid() = user_id);

-- ────────────────────────────────────────────
-- Tabela: platform_rates (taxas comerciais — Caio)
-- Atualizável pelo admin sem redeployar
-- ────────────────────────────────────────────
create table if not exists public.platform_rates (
  id           uuid default gen_random_uuid() primary key,
  platform     text not null,          -- ex: "Kiwify", "Hotmart"
  rate_type    text not null,          -- ex: "transaction_fee_pct", "fixed_fee_brl"
  rate_value   numeric not null,
  conditions   text,                   -- texto livre sobre quando se aplica
  source_url   text,
  verified_at  date,
  created_at   timestamptz default now(),
  updated_at   timestamptz default now()
);

-- Taxas são públicas para leitura (somente admin escreve via service role)
alter table public.platform_rates enable row level security;

create policy "Qualquer usuário autenticado lê taxas"
  on public.platform_rates for select
  to authenticated using (true);

-- Dados iniciais — verificar e atualizar antes de usar em produção
insert into public.platform_rates (platform, rate_type, rate_value, conditions, source_url, verified_at)
values
  ('Kiwify',  'transaction_fee_pct', 9.99,  'Plano gratuito, por transação aprovada',    'https://kiwify.com.br/precos',  '2024-01-01'),
  ('Hotmart', 'transaction_fee_pct', 9.90,  'Taxa padrão Hotmart + 0,5% repasse',        'https://hotmart.com/pt-BR/blog/taxas', '2024-01-01'),
  ('Eduzz',   'transaction_fee_pct', 8.90,  'Taxa Eduzz plano básico',                   'https://eduzz.com',             '2024-01-01'),
  ('PayPal',  'transaction_fee_pct', 3.99,  'Taxa de recebimento Brasil',                'https://paypal.com/br',         '2024-01-01'),
  ('Stripe',  'transaction_fee_pct', 2.90,  'Cartão de crédito, doméstico',              'https://stripe.com/br/pricing', '2024-01-01'),
  ('Stripe',  'fixed_fee_brl',       0.30,  'Taxa fixa por transação',                   'https://stripe.com/br/pricing', '2024-01-01')
on conflict do nothing;

create trigger platform_rates_updated_at
  before update on public.platform_rates
  for each row execute procedure public.touch_updated_at();

-- ────────────────────────────────────────────
-- Índices
-- ────────────────────────────────────────────
create index if not exists sessions_user_id_idx     on public.sessions(user_id);
create index if not exists sessions_assistant_idx   on public.sessions(assistant);
create index if not exists messages_session_id_idx  on public.messages(session_id);
