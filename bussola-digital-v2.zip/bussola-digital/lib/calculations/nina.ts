/**
 * Cálculos determinísticos da NINA — Métricas e Campanhas
 */

export interface CampaignMetricsInput {
  spend:              number | null;   // valor gasto (R$)
  impressions:        number | null;   // impressões
  linkClicks:         number | null;   // cliques no link
  landingPageViews:   number | null;   // visualizações da página de destino
  checkoutInitiated:  number | null;   // finalizações de compra iniciadas
  purchases:          number | null;   // compras atribuídas
  purchaseValue:      number | null;   // valor total das compras atribuídas (R$)
  reach:              number | null;   // alcance (opcional)
  actions:            number | null;   // ações (opcional)
  messageConversations: number | null; // conversas por mensagem iniciadas (opcional)
}

export interface CampaignMetricsResult {
  cpc:                    number | null;  // custo por clique no link
  cpm:                    number | null;  // custo por mil impressões
  ctr:                    number | null;  // taxa de cliques no link (%)
  costPerPurchase:        number | null;  // custo por compra
  roas:                   number | null;  // retorno sobre o investimento em anúncio
  avgOrderValue:          number | null;  // ticket médio das compras
  costPerCheckout:        number | null;  // custo por finalização de compra iniciada
  landingToCheckoutPct:   number | null;  // taxa de conversão: landing → checkout
  checkoutToPurchasePct:  number | null;  // taxa de conversão: checkout → compra
  landingToPurchasePct:   number | null;  // taxa de conversão: landing → compra
  unavailableMetrics:     string[];       // métricas que não puderam ser calculadas
  warnings:               string[];       // inconsistências detectadas
}

export function calculateCampaignMetrics(
  input: CampaignMetricsInput
): CampaignMetricsResult {
  const unavailable: string[] = [];
  const warnings:    string[] = [];

  const cpc = safeDiv(input.spend, input.linkClicks, "CPC do link", unavailable);
  const cpm = safeDiv(
    input.spend != null && input.impressions != null
      ? input.spend * 1000
      : null,
    input.impressions,
    "CPM",
    unavailable
  );
  const ctr = safeDiv(
    input.linkClicks != null && input.impressions != null
      ? input.linkClicks * 100
      : null,
    input.impressions,
    "CTR do link",
    unavailable
  );
  const costPerPurchase = safeDiv(
    input.spend,
    input.purchases,
    "Custo por compra",
    unavailable
  );
  const roas = safeDiv(
    input.purchaseValue,
    input.spend,
    "ROAS",
    unavailable
  );

  const avgOrderValue =
    input.purchaseValue != null && input.purchases != null && input.purchases > 0
      ? round(input.purchaseValue / input.purchases)
      : null;
  if (avgOrderValue === null && (input.purchaseValue !== null || input.purchases !== null)) {
    unavailable.push("Ticket médio");
  }

  const costPerCheckout = safeDiv(
    input.spend,
    input.checkoutInitiated,
    "Custo por finalização de compra iniciada",
    unavailable
  );

  const landingToCheckoutPct = safeDiv(
    input.checkoutInitiated != null && input.landingPageViews != null
      ? input.checkoutInitiated * 100
      : null,
    input.landingPageViews,
    "Taxa landing → checkout",
    unavailable
  );

  const checkoutToPurchasePct = safeDiv(
    input.purchases != null && input.checkoutInitiated != null
      ? input.purchases * 100
      : null,
    input.checkoutInitiated,
    "Taxa checkout → compra",
    unavailable
  );

  const landingToPurchasePct = safeDiv(
    input.purchases != null && input.landingPageViews != null
      ? input.purchases * 100
      : null,
    input.landingPageViews,
    "Taxa landing → compra",
    unavailable
  );

  // Alertas de consistência
  if (input.purchases != null && input.checkoutInitiated != null) {
    if (input.purchases > input.checkoutInitiated) {
      warnings.push(
        "Atenção: o número de compras é maior que o de finalizações de compra iniciadas. Verifique se o rastreamento está configurado corretamente."
      );
    }
  }
  if (input.landingPageViews != null && input.linkClicks != null) {
    if (input.landingPageViews > input.linkClicks * 1.1) {
      warnings.push(
        "Visualizações da página de destino acima do esperado em relação aos cliques. Pode haver tráfego de outras fontes não contabilizadas."
      );
    }
  }

  return {
    cpc,
    cpm,
    ctr,
    costPerPurchase,
    roas,
    avgOrderValue,
    costPerCheckout,
    landingToCheckoutPct,
    checkoutToPurchasePct,
    landingToPurchasePct,
    unavailableMetrics: unavailable,
    warnings,
  };
}

/** Divide dois valores nulos de forma segura */
function safeDiv(
  numerator: number | null,
  denominator: number | null,
  metricName: string,
  unavailable: string[]
): number | null {
  if (numerator === null || denominator === null) {
    unavailable.push(`${metricName} (dados insuficientes)`);
    return null;
  }
  if (denominator === 0) {
    unavailable.push(`${metricName} (denominador igual a zero)`);
    return null;
  }
  return round(numerator / denominator);
}

function round(n: number, decimals = 2): number {
  return Math.round(n * 10 ** decimals) / 10 ** decimals;
}
