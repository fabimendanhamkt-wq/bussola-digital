/**
 * Cálculos determinísticos do CAIO — Precificação e Finanças
 * Executados no servidor, não delegados ao modelo de IA.
 */

export interface PricingInput {
  price: number;               // preço de venda (R$)
  platformFeePct: number;      // taxa da plataforma (%)
  paymentFeePct: number;       // taxa de pagamento (%)
  paymentFeeFixed: number;     // taxa fixa por transação (R$)
  affiliatePct: number;        // comissão de afiliados (%)
  adSpendPerSale: number;      // custo médio de anúncios por venda (R$)
  otherVariableCosts: number;  // outros custos variáveis por venda (R$)
  fixedCostsMonthly: number;   // despesas fixas mensais (R$)
  taxPct: number;              // impostos (%) — informado pela aluna
  targetSalesPerMonth: number; // meta de vendas/mês
}

export interface PricingResult {
  grossRevenue: number;           // receita bruta por venda
  platformFee: number;            // taxa da plataforma
  paymentFee: number;             // taxa de pagamento (% + fixo)
  affiliateFee: number;           // comissão de afiliados
  taxAmount: number;              // impostos
  adSpendPerSale: number;         // custo de anúncios
  otherVariable: number;          // outros custos variáveis
  totalVariableCosts: number;     // total de custos variáveis
  contributionMargin: number;     // margem de contribuição (R$)
  contributionMarginPct: number;  // margem de contribuição (%)
  breakEvenUnits: number;         // ponto de equilíbrio (unidades/mês)
  projectedMonthlyProfit: number; // lucro estimado no mês (meta de vendas)
  isViable: boolean;              // preço cobre todos os custos?
  warnings: string[];             // alertas para exibir à aluna
}

export function calculatePricing(input: PricingInput): PricingResult {
  const warnings: string[] = [];

  // Validações
  if (input.price <= 0) {
    warnings.push("O preço informado deve ser maior que zero.");
  }
  if (input.platformFeePct < 0 || input.platformFeePct > 100) {
    warnings.push("Taxa da plataforma fora do intervalo válido (0–100%).");
  }
  if (input.taxPct < 0 || input.taxPct > 100) {
    warnings.push("Percentual de imposto fora do intervalo válido (0–100%).");
  }

  const p = input.price;

  // Taxas sobre o preço de venda
  const platformFee  = (p * input.platformFeePct) / 100;
  const paymentFee   = (p * input.paymentFeePct) / 100 + input.paymentFeeFixed;
  const affiliateFee = (p * input.affiliatePct) / 100;
  const taxAmount    = (p * input.taxPct) / 100;

  const totalVariableCosts =
    platformFee +
    paymentFee +
    affiliateFee +
    taxAmount +
    input.adSpendPerSale +
    input.otherVariableCosts;

  const contributionMargin    = p - totalVariableCosts;
  const contributionMarginPct = p > 0 ? (contributionMargin / p) * 100 : 0;

  // Ponto de equilíbrio — evitar divisão por zero
  let breakEvenUnits = 0;
  if (contributionMargin > 0) {
    breakEvenUnits = Math.ceil(input.fixedCostsMonthly / contributionMargin);
  } else if (input.fixedCostsMonthly > 0) {
    breakEvenUnits = Infinity;
    warnings.push(
      "A margem de contribuição é zero ou negativa. O ponto de equilíbrio não pode ser calculado com este preço."
    );
  }

  const projectedMonthlyProfit =
    contributionMargin * input.targetSalesPerMonth - input.fixedCostsMonthly;

  const isViable = contributionMargin > 0;

  if (!isViable) {
    warnings.push(
      "⚠️ Este preço não cobre os custos variáveis considerados. Revise o preço ou os custos."
    );
  }

  if (projectedMonthlyProfit < 0 && isViable) {
    warnings.push(
      `⚠️ Com ${input.targetSalesPerMonth} vendas/mês, o resultado é negativo (R$${Math.abs(projectedMonthlyProfit).toFixed(2)} de prejuízo). Serão necessárias ${breakEvenUnits} vendas/mês para cobrir os custos fixos.`
    );
  }

  return {
    grossRevenue: p,
    platformFee:  round(platformFee),
    paymentFee:   round(paymentFee),
    affiliateFee: round(affiliateFee),
    taxAmount:    round(taxAmount),
    adSpendPerSale: round(input.adSpendPerSale),
    otherVariable:  round(input.otherVariableCosts),
    totalVariableCosts: round(totalVariableCosts),
    contributionMargin:    round(contributionMargin),
    contributionMarginPct: round(contributionMarginPct),
    breakEvenUnits: isFinite(breakEvenUnits) ? breakEvenUnits : -1,
    projectedMonthlyProfit: round(projectedMonthlyProfit),
    isViable,
    warnings,
  };
}

/** Calcula múltiplos cenários de preço em um único call */
export function calculateScenarios(
  baseInput: Omit<PricingInput, "price">,
  prices: number[]
): Array<{ price: number; result: PricingResult }> {
  return prices.map((price) => ({
    price,
    result: calculatePricing({ ...baseInput, price }),
  }));
}

function round(n: number, decimals = 2): number {
  return Math.round(n * 10 ** decimals) / 10 ** decimals;
}
