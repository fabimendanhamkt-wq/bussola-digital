/**
 * Camada de serviço de IA — provedor configurável via AI_PROVIDER env.
 * Padrão: "gemini" (Google Gemini 1.5 Flash — gratuito, 1500 req/dia)
 * Alternativa: "openai" (requer OPENAI_API_KEY)
 */

export interface AIMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface AIResponse {
  content: string;
  usage?: { prompt_tokens: number; completion_tokens: number };
}

export async function callAI(
  messages: AIMessage[],
  options?: { temperature?: number; max_tokens?: number }
): Promise<AIResponse> {
  const provider = process.env.AI_PROVIDER ?? "gemini";

  if (provider === "gemini") {
    return callGemini(messages, options);
  }

  if (provider === "openai") {
    return callOpenAI(messages, options);
  }

  throw new Error(`Provedor de IA não suportado: ${provider}`);
}

// ─── Google Gemini (gratuito) ────────────────────────────────────────────────

async function callGemini(
  messages: AIMessage[],
  options?: { temperature?: number; max_tokens?: number }
): Promise<AIResponse> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) throw new Error("GEMINI_API_KEY não configurada.");

  // Gemini separa o system prompt dos turnos de conversa
  const systemMsg = messages.find((m) => m.role === "system");
  const turns = messages.filter((m) => m.role !== "system");

  // Converter para formato Gemini (user/model)
  const contents = turns.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));

  const body: Record<string, unknown> = {
    contents,
    generationConfig: {
      temperature: options?.temperature ?? 0.4,
      maxOutputTokens: options?.max_tokens ?? 2000,
    },
  };

  if (systemMsg) {
    body.systemInstruction = { parts: [{ text: systemMsg.content }] };
  }

  const model = "gemini-1.5-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Gemini API error ${res.status}: ${err}`);
  }

  const data = await res.json();
  const text: string =
    data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";

  const usage = data?.usageMetadata
    ? {
        prompt_tokens: data.usageMetadata.promptTokenCount ?? 0,
        completion_tokens: data.usageMetadata.candidatesTokenCount ?? 0,
      }
    : undefined;

  return { content: text, usage };
}

// ─── OpenAI (alternativo) ────────────────────────────────────────────────────

async function callOpenAI(
  messages: AIMessage[],
  options?: { temperature?: number; max_tokens?: number }
): Promise<AIResponse> {
  const { default: OpenAI } = await import("openai");
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const completion = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages,
    temperature: options?.temperature ?? 0.4,
    max_tokens: options?.max_tokens ?? 2000,
  });

  const choice = completion.choices[0];
  return {
    content: choice.message.content ?? "",
    usage: completion.usage
      ? {
          prompt_tokens: completion.usage.prompt_tokens,
          completion_tokens: completion.usage.completion_tokens,
        }
      : undefined,
  };
}
