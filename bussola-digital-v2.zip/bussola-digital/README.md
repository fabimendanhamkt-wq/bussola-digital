# 🧭 Bússola Digital®

**Plataforma de apoio à execução para professoras que desejam transformar seus conhecimentos em produtos digitais comercializáveis.**

Projeto: Escola Da Sala ao Digital® — Prof. Fabi Mendanha

---

## Assistentes

| Assistente | Missão | Entrega |
|---|---|---|
| **Clara** | Pesquisa e Produto | Plano de Produto Pedagógico |
| **Bia** | Oferta e Comunicação | Dossiê de Oferta e Divulgação |
| **Caio** | Precificação e Finanças | Relatório de Precificação |
| **Nina** | Métricas e Campanhas | Diagnóstico de Campanha |

---

## Stack

- **Front-end:** Next.js 14 + TypeScript
- **Estilos:** Tailwind CSS
- **Banco de dados + Auth:** Supabase
- **Hospedagem:** Vercel
- **IA:** OpenAI GPT-4o-mini (provedor configurável via env)

---

## Configuração local

### 1. Clonar e instalar

```bash
git clone <seu-repositorio>
cd bussola-digital
npm install
```

### 2. Variáveis de ambiente

```bash
cp .env.local.example .env.local
# Preencha com suas chaves do Supabase e OpenAI
```

### 3. Banco de dados

No painel do Supabase, abra **SQL Editor** e execute o conteúdo de `supabase/schema.sql`.

### 4. Rodar localmente

```bash
npm run dev
# Acesse http://localhost:3000
```

---

## Deploy (Vercel)

1. Criar projeto no [Vercel](https://vercel.com) conectado ao repositório GitHub.
2. Adicionar as variáveis de ambiente do `.env.local.example` no painel do Vercel.
3. Configurar as URLs permitidas no Supabase → Authentication → URL Configuration:
   - Site URL: `https://seu-dominio.vercel.app`
   - Redirect URLs: `https://seu-dominio.vercel.app/**`
4. Deploy automático a cada push na branch `main`.

---

## Estrutura do projeto

```
app/
  (auth)/login/         — Autenticação
  (dashboard)/
    dashboard/          — Painel inicial
    clara/              — Assistente Clara
    bia/                — Assistente Bia
    caio/               — Assistente Caio (+ formulário de precificação)
    nina/               — Assistente Nina (+ formulário de métricas)
  api/
    clara/              — Rota de API: Clara
    bia/                — Rota de API: Bia
    caio/               — Rota de API: Caio (cálculos determinísticos)
    nina/               — Rota de API: Nina (cálculos determinísticos)
    sessions/           — CRUD de trabalhos salvos
    rates/              — Taxas de plataforma

lib/
  ai/service.ts         — Camada de IA (provedor configurável)
  calculations/
    caio.ts             — Cálculos de precificação
    nina.ts             — Cálculos de métricas
  prompts/
    clara.ts            — Instruções da Clara (separadas do código)
    bia.ts              — Instruções da Bia
    caio.ts             — Instruções do Caio
    nina.ts             — Instruções da Nina
  supabase/             — Clientes Supabase (browser, server, middleware)

components/ui/
  AssistantCard.tsx     — Cartão do painel inicial
  ChatInterface.tsx     — Interface de chat compartilhada
  DashboardNav.tsx      — Navegação superior
  RecentSessions.tsx    — Trabalhos recentes

supabase/
  schema.sql            — Schema completo do banco de dados
```

---

## Princípio de qualidade

> A Bússola Digital deverá reduzir a distância entre **saber o que fazer** e **efetivamente fazer**.

Nenhum resultado, fonte, taxa ou integração é apresentado como real sem ter sido verificado.

---

## Roadmap pós-MVP

- [ ] Conexão automática com Meta Ads (importação de campanhas)
- [ ] Pesquisa verificável da Clara via Serper API
- [ ] Atualização automática de taxas comerciais
- [ ] Comparação avançada de campanhas (Nina)
- [ ] Exportação em PDF formatado
- [ ] Painel de administração
