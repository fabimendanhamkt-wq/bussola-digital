import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bússola Digital® — Escola Da Sala ao Digital",
  description:
    "Plataforma de apoio à execução para professoras que desejam transformar seus conhecimentos em produtos digitais comercializáveis.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  );
}
