import ChatInterface from "@/components/ui/ChatInterface";

export default function ClaraPage() {
  return (
    <ChatInterface
      assistant="clara"
      title="Clara"
      subtitle="Pesquisa e Produto"
      avatar="/avatars/clara-avatar.png"
      accentClass="text-compass-clara"
      placeholder="Descreva sua ideia ou diga em qual tema você leciona. A Clara vai investigar oportunidades para você."
    />
  );
}
