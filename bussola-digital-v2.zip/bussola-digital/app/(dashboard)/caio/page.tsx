"use client";

import { useState } from "react";
import ChatInterface from "@/components/ui/ChatInterface";

export default function CaioPage() {
  const [showForm, setShowForm] = useState(false);
  const [pricingInput, setPricingInput] = useState({
    price: "",
    platformFeePct: "",
    paymentFeePct: "",
    paymentFeeFixed: "",
    affiliatePct: "0",
    adSpendPerSale: "0",
    otherVariableCosts: "0",
    fixedCostsMonthly: "0",
    taxPct: "0",
    targetSalesPerMonth: "10",
  });
  const [submitted, setSubmitted] = useState<Record<string, number> | null>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setPricingInput((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed: Record<string, number> = {};
    for (const [k, v] of Object.entries(pricingInput)) {
      parsed[k] = parseFloat(v) || 0;
    }
    setSubmitted(parsed);
    setShowForm(false);
  }

  return (
    <div className="space-y-4">
      {/* Formulário de precificação */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-bold">Dados para precificação</h2>
          <button
            onClick={() => setShowForm(!showForm)}
            className="btn-ghost text-sm"
          >
            {showForm ? "Fechar" : submitted ? "Editar" : "Preencher"}
          </button>
        </div>

        {submitted && !showForm && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            <Stat label="Preço (R$)" value={`R$ ${submitted.price.toFixed(2)}`} />
            <Stat label="Taxa plataforma" value={`${submitted.platformFeePct}%`} />
            <Stat label="Despesas fixas/mês" value={`R$ ${submitted.fixedCostsMonthly.toFixed(2)}`} />
            <Stat label="Meta de vendas/mês" value={String(submitted.targetSalesPerMonth)} />
          </div>
        )}

        {!submitted && !showForm && (
          <p className="text-sm text-compass-muted">
            Preencha os dados financeiros para o Caio calcular cenários de preço.
            Você pode pular esta etapa e conversar diretamente com ele também.
          </p>
        )}

        {showForm && (
          <form onSubmit={handleSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
            <Field label="Preço de venda (R$)*" name="price" value={pricingInput.price} onChange={handleChange} required />
            <Field label="Taxa da plataforma (%)*" name="platformFeePct" value={pricingInput.platformFeePct} onChange={handleChange} required placeholder="ex: 9.99 para Kiwify" />
            <Field label="Taxa de pagamento (%)" name="paymentFeePct" value={pricingInput.paymentFeePct} onChange={handleChange} placeholder="ex: 0 se inclusa na plataforma" />
            <Field label="Taxa fixa por transação (R$)" name="paymentFeeFixed" value={pricingInput.paymentFeeFixed} onChange={handleChange} placeholder="ex: 0.30 para Stripe" />
            <Field label="Comissão de afiliados (%)" name="affiliatePct" value={pricingInput.affiliatePct} onChange={handleChange} />
            <Field label="Custo médio de anúncios por venda (R$)" name="adSpendPerSale" value={pricingInput.adSpendPerSale} onChange={handleChange} />
            <Field label="Outros custos variáveis por venda (R$)" name="otherVariableCosts" value={pricingInput.otherVariableCosts} onChange={handleChange} />
            <Field label="Despesas fixas mensais (R$)" name="fixedCostsMonthly" value={pricingInput.fixedCostsMonthly} onChange={handleChange} />
            <Field label="Imposto (% sobre o preço)" name="taxPct" value={pricingInput.taxPct} onChange={handleChange} placeholder="Consulte seu contador" />
            <Field label="Meta de vendas por mês" name="targetSalesPerMonth" value={pricingInput.targetSalesPerMonth} onChange={handleChange} />

            <div className="sm:col-span-2">
              <button type="submit" className="btn-primary">Calcular cenários</button>
            </div>
          </form>
        )}
      </div>

      {/* Chat */}
      <ChatInterface
        assistant="caio"
        title="Caio"
        subtitle="Precificação e Finanças"
        avatar="/avatars/caio-avatar.png"
        accentClass="text-compass-caio"
        placeholder="Qual produto você quer precificar? Descreva o que sabe sobre seus custos."
        extraPayload={submitted ? { pricingInput: submitted, scenarioPrices: [submitted.price * 0.8, submitted.price, submitted.price * 1.25].map(Math.round) } : undefined}
      />
    </div>
  );
}

function Field({ label, name, value, onChange, placeholder, required }: {
  label: string; name: string; value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string; required?: boolean;
}) {
  return (
    <div>
      <label className="label">{label}</label>
      <input
        type="number"
        step="0.01"
        min="0"
        name={name}
        className="input-field"
        value={value}
        onChange={onChange}
        placeholder={placeholder ?? "0"}
        required={required}
      />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-compass-cream rounded-xl p-3">
      <div className="text-xs text-compass-muted">{label}</div>
      <div className="font-semibold text-sm mt-0.5">{value}</div>
    </div>
  );
}
