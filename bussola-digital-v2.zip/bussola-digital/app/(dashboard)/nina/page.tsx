"use client";

import { useState } from "react";
import ChatInterface from "@/components/ui/ChatInterface";

const METRICS = [
  { key: "spend",               label: "Valor gasto (R$)",                   essential: true  },
  { key: "impressions",         label: "Impressões",                          essential: false },
  { key: "linkClicks",          label: "Cliques no link",                     essential: true  },
  { key: "landingPageViews",    label: "Visualizações da página de destino",  essential: true  },
  { key: "checkoutInitiated",   label: "Finalizações de compra iniciadas",    essential: false },
  { key: "purchases",           label: "Compras atribuídas",                  essential: true  },
  { key: "purchaseValue",       label: "Valor das compras (R$)",              essential: false },
  { key: "reach",               label: "Alcance",                             essential: false },
  { key: "messageConversations",label: "Conversas por mensagem iniciadas",    essential: false },
];

export default function NinaPage() {
  const [showForm, setShowForm] = useState(false);
  const [values, setValues] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState<Record<string, number | null> | null>(null);

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    setValues((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed: Record<string, number | null> = {};
    for (const m of METRICS) {
      const v = values[m.key];
      parsed[m.key] = v && v.trim() !== "" ? parseFloat(v) : null;
    }
    setSubmitted(parsed);
    setShowForm(false);
  }

  const essentialCount = Object.entries(submitted ?? {}).filter(
    ([k, v]) => v !== null && METRICS.find((m) => m.key === k)?.essential
  ).length;

  return (
    <div className="space-y-4">
      {/* Formulário de métricas */}
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-bold">Dados da campanha</h2>
          <button onClick={() => setShowForm(!showForm)} className="btn-ghost text-sm">
            {showForm ? "Fechar" : submitted ? "Editar" : "Preencher"}
          </button>
        </div>

        {submitted && !showForm && (
          <div>
            <p className="text-sm text-compass-muted mb-3">
              {essentialCount} indicadores essenciais preenchidos.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
              {METRICS.filter((m) => submitted[m.key] !== null).map((m) => (
                <div key={m.key} className="bg-compass-cream rounded-xl p-3">
                  <div className="text-xs text-compass-muted">{m.label}</div>
                  <div className="font-semibold text-sm mt-0.5">
                    {m.key === "spend" || m.key === "purchaseValue"
                      ? `R$ ${Number(submitted[m.key]).toFixed(2)}`
                      : submitted[m.key]}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {!submitted && !showForm && (
          <p className="text-sm text-compass-muted">
            Preencha os dados da sua campanha para a Nina calcular os indicadores e
            identificar o que merece atenção. Não é obrigatório preencher tudo.
          </p>
        )}

        {showForm && (
          <form onSubmit={handleSubmit} className="mt-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {METRICS.map((m) => (
                <div key={m.key}>
                  <label className="label">
                    {m.label}
                    {m.essential && <span className="text-compass-nina ml-1 text-xs">recomendado</span>}
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    name={m.key}
                    className="input-field"
                    value={values[m.key] ?? ""}
                    onChange={handleChange}
                    placeholder="deixe em branco se não souber"
                  />
                </div>
              ))}
            </div>
            <div className="mt-4">
              <button type="submit" className="btn-primary">Analisar métricas</button>
            </div>
          </form>
        )}
      </div>

      {/* Chat */}
      <ChatInterface
        assistant="nina"
        title="Nina"
        subtitle="Métricas e Campanhas"
        avatar="/avatars/nina-avatar.png"
        accentClass="text-compass-nina"
        placeholder="Descreva sua campanha: objetivo, período e o que está te preocupando nos resultados."
        extraPayload={submitted ? { metricsInput: submitted } : undefined}
      />
    </div>
  );
}
