import { createServerClient } from "@/lib/supabase/server";
import AssistantCard from "@/components/ui/AssistantCard";
import RecentSessions from "@/components/ui/RecentSessions";

const ASSISTANTS = [
  {
    id: "clara",
    name: "Clara",
    subtitle: "Pesquisa e Produto",
    description:
      "Descubra o que vale a pena transformar em produto pedagógico e defina o que produzir primeiro.",
    avatar: "/avatars/clara-avatar.png",
    color: "clara" as const,
    deliverable: "Plano de Produto Pedagógico",
  },
  {
    id: "bia",
    name: "Bia",
    subtitle: "Oferta e Comunicação",
    description:
      "Transforme seu produto em uma oferta clara e em conteúdos prontos para divulgar.",
    avatar: "/avatars/bia-avatar.png",
    color: "bia" as const,
    deliverable: "Dossiê de Oferta e Divulgação",
  },
  {
    id: "caio",
    name: "Caio",
    subtitle: "Precificação e Finanças",
    description:
      "Defina preços sustentáveis e entenda quanto sobra por venda em cada cenário.",
    avatar: "/avatars/caio-avatar.png",
    color: "caio" as const,
    deliverable: "Relatório de Precificação",
  },
  {
    id: "nina",
    name: "Nina",
    subtitle: "Métricas e Campanhas",
    description:
      "Interprete os resultados das suas campanhas e escolha o próximo passo com segurança.",
    avatar: "/avatars/nina-avatar.png",
    color: "nina" as const,
    deliverable: "Diagnóstico de Campanha",
  },
];

export default async function DashboardPage() {
  const supabase = createServerClient();
  const { data: { user } } = await supabase.auth.getUser();

  const firstName = user?.user_metadata?.full_name?.split(" ")[0] ?? "Professora";

  const { data: sessions } = await supabase
    .from("sessions")
    .select("id, assistant, title, status, updated_at")
    .eq("user_id", user!.id)
    .order("updated_at", { ascending: false })
    .limit(6);

  return (
    <div className="space-y-10">
      {/* Boas-vindas */}
      <div>
        <h1 className="text-3xl font-display font-bold">
          Olá, {firstName}! 👋
        </h1>
        <p className="text-compass-muted mt-1">
          Com qual assistente você quer trabalhar hoje?
        </p>
      </div>

      {/* Cartões dos assistentes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {ASSISTANTS.map((a) => (
          <AssistantCard key={a.id} {...a} />
        ))}
      </div>

      {/* Método — resumo visual */}
      <div className="card">
        <h2 className="text-lg font-display font-bold mb-4">
          Método Da Gaveta à Oferta
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { step: "1", label: "Selecionar", desc: "Identificar a oportunidade" },
            { step: "2", label: "Estruturar",  desc: "Definir o produto e a oferta" },
            { step: "3", label: "Publicar",    desc: "Divulgar e vender" },
            { step: "4", label: "Analisar",    desc: "Interpretar e escalar" },
          ].map((s) => (
            <div key={s.step} className="flex gap-3 items-start">
              <div className="w-7 h-7 rounded-full bg-compass-teal/10 text-compass-teal text-sm font-bold flex items-center justify-center shrink-0">
                {s.step}
              </div>
              <div>
                <div className="font-semibold text-sm">{s.label}</div>
                <div className="text-xs text-compass-muted">{s.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Trabalhos recentes */}
      {sessions && sessions.length > 0 && (
        <div>
          <h2 className="text-lg font-display font-bold mb-4">Trabalhos recentes</h2>
          <RecentSessions sessions={sessions} />
        </div>
      )}
    </div>
  );
}
