import { redirect } from "next/navigation";
import { createServerClient } from "@/lib/supabase/server";
import DashboardNav from "@/components/ui/DashboardNav";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = createServerClient();
  const { data: { session } } = await supabase.auth.getSession();

  if (!session) redirect("/login");

  return (
    <div className="min-h-screen bg-compass-cream flex flex-col">
      <DashboardNav user={session.user} />
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8">
        {children}
      </main>
    </div>
  );
}
