import ChatInterface from "@/components/ui/ChatInterface";

export default function BiaPage() {
  return (
    <ChatInterface
      assistant="bia"
      title="Bia"
      subtitle="Oferta e Comunicação"
      avatar="/avatars/bia-avatar.png"
      accentClass="text-compass-bia"
      placeholder="Descreva o produto que você quer vender. A Bia vai ajudar a criar a oferta e os textos de divulgação."
    />
  );
}
