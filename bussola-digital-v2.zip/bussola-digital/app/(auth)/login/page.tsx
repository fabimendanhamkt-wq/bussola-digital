"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();

  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [confirmSent, setConfirmSent] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: fullName } },
        });
        if (error) throw error;
        setConfirmSent(true);
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push("/dashboard");
        router.refresh();
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro ao autenticar";
      // Traduzir erros comuns
      if (msg.includes("Invalid login credentials")) setError("E-mail ou senha incorretos.");
      else if (msg.includes("Email not confirmed")) setError("Confirme seu e-mail antes de entrar.");
      else if (msg.includes("User already registered")) setError("Este e-mail já está cadastrado.");
      else setError(msg);
    } finally {
      setLoading(false);
    }
  }

  if (confirmSent) {
    return (
      <div className="min-h-screen bg-compass-cream flex items-center justify-center p-4">
        <div className="card max-w-md w-full text-center">
          <div className="text-4xl mb-4">✉️</div>
          <h2 className="text-xl font-display font-bold mb-2">Confirme seu e-mail</h2>
          <p className="text-compass-muted text-sm">
            Enviamos um link de confirmação para <strong>{email}</strong>. Acesse seu e-mail e clique no link para ativar sua conta.
          </p>
          <button onClick={() => { setConfirmSent(false); setIsSignUp(false); }} className="btn-ghost mt-4 text-sm">
            Voltar para entrar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-compass-cream flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-2">
            <span className="text-3xl">🧭</span>
            <span className="text-2xl font-display font-bold text-compass-navy">Bússola Digital®</span>
          </div>
          <p className="text-sm text-compass-muted">Escola Da Sala ao Digital®</p>
        </div>

        <div className="card">
          <h1 className="text-xl font-display font-bold mb-1">
            {isSignUp ? "Criar sua conta" : "Entrar na plataforma"}
          </h1>
          <p className="text-sm text-compass-muted mb-6">
            {isSignUp
              ? "Preencha os dados abaixo para começar."
              : "Bem-vinda de volta! Informe seus dados."}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div>
                <label className="label">Nome completo</label>
                <input
                  type="text"
                  className="input-field"
                  placeholder="Seu nome"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                />
              </div>
            )}

            <div>
              <label className="label">E-mail</label>
              <input
                type="email"
                className="input-field"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="label">Senha</label>
              <input
                type="password"
                className="input-field"
                placeholder={isSignUp ? "Mínimo 8 caracteres" : "Sua senha"}
                minLength={isSignUp ? 8 : undefined}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            )}

            <button type="submit" className="btn-primary w-full" disabled={loading}>
              {loading ? "Aguarde..." : isSignUp ? "Criar conta" : "Entrar"}
            </button>
          </form>

          <div className="mt-4 text-center text-sm text-compass-muted">
            {isSignUp ? "Já tem uma conta?" : "Ainda não tem conta?"}{" "}
            <button
              onClick={() => { setIsSignUp(!isSignUp); setError(null); }}
              className="text-compass-teal font-medium hover:underline"
            >
              {isSignUp ? "Entrar" : "Criar conta"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
