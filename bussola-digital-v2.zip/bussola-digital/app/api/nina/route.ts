import { NextRequest, NextResponse } from "next/server";
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";
import { callAI } from "@/lib/ai/service";
import { NINA_SYSTEM } from "@/lib/prompts/nina";
import { calculateCampaignMetrics, type CampaignMetricsInput } from "@/lib/calculations/nina";

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const { messages, sessionId, metricsInput } = await request.json();

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Mensagens inválidas" }, { status: 400 });
    }

    let calculationContext = "";
    if (metricsInput) {
      try {
        const result = calculateCampaignMetrics(metricsInput as CampaignMetricsInput);

        const fmt = (v: number | null, prefix = "", suffix = "") =>
          v !== null ? `${prefix}${v}${suffix}` : "não disponível";

        calculationContext = `
MÉTRICAS CALCULADAS PELO SISTEMA:
CPC do link: ${fmt(result.cpc, "R$")}
CPM: ${fmt(result.cpm, "R$")}
CTR do link: ${fmt(result.ctr, "", "%")}
Custo por compra: ${fmt(result.costPerPurchase, "R$")}
ROAS: ${fmt(result.roas)}
Ticket médio: ${fmt(result.avgOrderValue, "R$")}
Custo por checkout iniciado: ${fmt(result.costPerCheckout, "R$")}
Taxa landing → checkout: ${fmt(result.landingToCheckoutPct, "", "%")}
Taxa checkout → compra: ${fmt(result.checkoutToPurchasePct, "", "%")}
Taxa landing → compra: ${fmt(result.landingToPurchasePct, "", "%")}

Métricas não calculáveis: ${result.unavailableMetrics.join(", ") || "nenhuma"}
Alertas de consistência: ${result.warnings.join("; ") || "nenhum"}
`;
      } catch (calcError) {
        console.error("[NINA] Erro nos cálculos:", calcError);
        calculationContext = "\n[Erro ao calcular métricas. Solicite à aluna que revise os valores informados.]\n";
      }
    }

    const systemWithCalc = calculationContext
      ? NINA_SYSTEM + "\n\n" + calculationContext
      : NINA_SYSTEM;

    const aiMessages = [
      { role: "system" as const, content: systemWithCalc },
      ...messages.map((m: { role: string; content: string }) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    const response = await callAI(aiMessages, { temperature: 0.3, max_tokens: 2500 });

    if (sessionId) {
      await supabase.from("messages").insert([
        {
          session_id: sessionId,
          user_id: user.id,
          role: "assistant",
          content: response.content,
        },
      ]);
    }

    return NextResponse.json({ content: response.content });
  } catch (error: unknown) {
    console.error("[NINA] Erro:", error);
    const message = error instanceof Error ? error.message : "Erro interno";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
