import { NextRequest, NextResponse } from "next/server";
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";
import { callAI } from "@/lib/ai/service";
import { CAIO_SYSTEM } from "@/lib/prompts/caio";
import { calculatePricing, calculateScenarios, type PricingInput } from "@/lib/calculations/caio";

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const { messages, sessionId, pricingInput, scenarioPrices } = await request.json();

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Mensagens inválidas" }, { status: 400 });
    }

    // Cálculos determinísticos antes de chamar a IA
    let calculationContext = "";
    if (pricingInput) {
      try {
        const input = pricingInput as PricingInput;
        const singleResult = calculatePricing(input);

        let scenariosText = "";
        if (Array.isArray(scenarioPrices) && scenarioPrices.length > 0) {
          const scenarios = calculateScenarios(
            { ...input, price: 0 },
            scenarioPrices
          );
          scenariosText = "\n\nCENÁRIOS CALCULADOS:\n" +
            scenarios.map(s =>
              `Preço R$${s.price}: margem R$${s.result.contributionMargin} (${s.result.contributionMarginPct}%), ponto de equilíbrio ${s.result.breakEvenUnits} vendas/mês`
            ).join("\n");
        }

        calculationContext = `
DADOS CALCULADOS PELO SISTEMA (use estes números na sua resposta):
Preço: R$${input.price}
Taxas totais: R$${singleResult.totalVariableCosts}
Margem de contribuição: R$${singleResult.contributionMargin} (${singleResult.contributionMarginPct}%)
Ponto de equilíbrio: ${singleResult.breakEvenUnits === -1 ? "não calculável" : singleResult.breakEvenUnits + " vendas/mês"}
Lucro estimado (${input.targetSalesPerMonth} vendas): R$${singleResult.projectedMonthlyProfit}
Produto viável: ${singleResult.isViable ? "Sim" : "Não"}
Alertas: ${singleResult.warnings.join("; ") || "nenhum"}
${scenariosText}
`;
      } catch (calcError) {
        console.error("[CAIO] Erro nos cálculos:", calcError);
        calculationContext = "\n[Erro ao processar os dados de precificação. Solicite à aluna que verifique os valores informados.]\n";
      }
    }

    const systemWithCalc = calculationContext
      ? CAIO_SYSTEM + "\n\n" + calculationContext
      : CAIO_SYSTEM;

    const aiMessages = [
      { role: "system" as const, content: systemWithCalc },
      ...messages.map((m: { role: string; content: string }) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    const response = await callAI(aiMessages, { temperature: 0.2, max_tokens: 2500 });

    if (sessionId) {
      await supabase.from("messages").insert([
        {
          session_id: sessionId,
          user_id: user.id,
          role: "assistant",
          content: response.content,
        },
      ]);
    }

    return NextResponse.json({ content: response.content });
  } catch (error: unknown) {
    console.error("[CAIO] Erro:", error);
    const message = error instanceof Error ? error.message : "Erro interno";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
