import { NextRequest, NextResponse } from "next/server";
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";

// GET — listar trabalhos da aluna
export async function GET(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const assistant = searchParams.get("assistant");

    let query = supabase
      .from("sessions")
      .select("id, assistant, title, status, created_at, updated_at")
      .eq("user_id", user.id)
      .order("updated_at", { ascending: false });

    if (assistant) query = query.eq("assistant", assistant);

    const { data, error } = await query;
    if (error) throw error;

    return NextResponse.json({ sessions: data });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Erro interno";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

// POST — criar novo trabalho
export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const { assistant, title, input_data } = await request.json();

    if (!["clara", "bia", "caio", "nina"].includes(assistant)) {
      return NextResponse.json({ error: "Assistente inválido" }, { status: 400 });
    }

    const { data, error } = await supabase
      .from("sessions")
      .insert([{ user_id: user.id, assistant, title: title || "Novo trabalho", input_data: input_data || {} }])
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ session: data }, { status: 201 });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Erro interno";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
