import { NextRequest, NextResponse } from "next/server";
import { createRouteHandlerClient } from "@supabase/auth-helpers-nextjs";
import { cookies } from "next/headers";
import { callAI } from "@/lib/ai/service";
import { CLARA_SYSTEM } from "@/lib/prompts/clara";

export async function POST(request: NextRequest) {
  try {
    const supabase = createRouteHandlerClient({ cookies });
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });

    const { messages, sessionId } = await request.json();

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ error: "Mensagens inválidas" }, { status: 400 });
    }

    const aiMessages = [
      { role: "system" as const, content: CLARA_SYSTEM },
      ...messages.map((m: { role: string; content: string }) => ({
        role: m.role as "user" | "assistant",
        content: m.content,
      })),
    ];

    const response = await callAI(aiMessages, { temperature: 0.3, max_tokens: 3000 });

    // Salvar mensagem do assistente no banco
    if (sessionId) {
      await supabase.from("messages").insert([
        {
          session_id: sessionId,
          user_id: user.id,
          role: "assistant",
          content: response.content,
        },
      ]);
    }

    return NextResponse.json({ content: response.content });
  } catch (error: unknown) {
    console.error("[CLARA] Erro:", error);
    const message = error instanceof Error ? error.message : "Erro interno";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
