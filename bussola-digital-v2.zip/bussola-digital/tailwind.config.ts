import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        compass: {
          navy:    "#1A2942",
          teal:    "#2A7B7B",
          amber:   "#E8A838",
          cream:   "#F9F6F0",
          muted:   "#6B7280",
          border:  "#E5E7EB",
          // per-assistant accent
          clara:   "#3B82F6",
          bia:     "#8B5CF6",
          caio:    "#10B981",
          nina:    "#F59E0B",
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)", "ui-sans-serif", "system-ui"],
        display: ["var(--font-outfit)", "ui-sans-serif"],
      },
      borderRadius: {
        "2xl": "1rem",
        "3xl": "1.5rem",
      },
      boxShadow: {
        card: "0 2px 12px 0 rgba(26,41,66,0.08)",
        "card-hover": "0 6px 24px 0 rgba(26,41,66,0.14)",
      },
    },
  },
  plugins: [],
};
export default config;
