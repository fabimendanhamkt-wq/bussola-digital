"use client";

import Link from "next/link";
import Image from "next/image";

interface AssistantCardProps {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  avatar: string;
  color: "clara" | "bia" | "caio" | "nina";
  deliverable: string;
}

const colorMap = {
  clara: { ring: "ring-compass-clara/20", bg: "bg-compass-clara/10", text: "text-compass-clara", dot: "bg-compass-clara" },
  bia:   { ring: "ring-compass-bia/20",   bg: "bg-compass-bia/10",   text: "text-compass-bia",   dot: "bg-compass-bia"   },
  caio:  { ring: "ring-compass-caio/20",  bg: "bg-compass-caio/10",  text: "text-compass-caio",  dot: "bg-compass-caio"  },
  nina:  { ring: "ring-compass-nina/20",  bg: "bg-compass-nina/10",  text: "text-compass-nina",  dot: "bg-compass-nina"  },
};

export default function AssistantCard({
  id, name, subtitle, description, avatar, color, deliverable,
}: AssistantCardProps) {
  const c = colorMap[color];

  return (
    <Link href={`/${id}`} className="card card-hover cursor-pointer group flex flex-col gap-4">
      <div className={`w-16 h-16 rounded-2xl overflow-hidden ring-2 ${c.ring} shrink-0`}>
        <Image
          src={avatar}
          alt={`Assistente ${name}`}
          width={64}
          height={64}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="flex-1">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-lg font-display font-bold">{name}</span>
          <span className={`badge ${c.bg} ${c.text}`}>{subtitle}</span>
        </div>
        <p className="text-sm text-compass-muted leading-snug">{description}</p>
      </div>

      <div className={`flex items-center gap-2 text-xs font-medium ${c.text}`}>
        <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />
        {deliverable}
      </div>
    </Link>
  );
}
