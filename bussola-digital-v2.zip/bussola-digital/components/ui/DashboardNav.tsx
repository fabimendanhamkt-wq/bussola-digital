"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { User } from "@supabase/supabase-js";

export default function DashboardNav({ user }: { user: User }) {
  const router = useRouter();
  const supabase = createClient();
  const name = user.user_metadata?.full_name?.split(" ")[0] ?? user.email;

  async function handleSignOut() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <header className="bg-white border-b border-compass-border sticky top-0 z-40">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link href="/dashboard" className="flex items-center gap-2 font-display font-bold text-compass-navy">
          <span className="text-xl">🧭</span>
          <span className="hidden sm:inline">Bússola Digital®</span>
        </Link>

        <div className="flex items-center gap-3">
          <span className="text-sm text-compass-muted hidden sm:inline">{name}</span>
          <button onClick={handleSignOut} className="btn-ghost text-sm">
            Sair
          </button>
        </div>
      </div>
    </header>
  );
}
