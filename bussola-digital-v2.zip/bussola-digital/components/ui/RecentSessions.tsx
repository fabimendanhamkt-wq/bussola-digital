"use client";

import Link from "next/link";

interface Session {
  id: string;
  assistant: string;
  title: string;
  status: string;
  updated_at: string;
}

const assistantMeta: Record<string, { icon: string; label: string; color: string }> = {
  clara: { icon: "🔍", label: "Clara",  color: "text-compass-clara" },
  bia:   { icon: "✍️", label: "Bia",    color: "text-compass-bia"   },
  caio:  { icon: "📊", label: "Caio",   color: "text-compass-caio"  },
  nina:  { icon: "📈", label: "Nina",   color: "text-compass-nina"  },
};

export default function RecentSessions({ sessions }: { sessions: Session[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {sessions.map((s) => {
        const meta = assistantMeta[s.assistant];
        const date = new Date(s.updated_at).toLocaleDateString("pt-BR", {
          day: "2-digit", month: "short",
        });

        return (
          <Link
            key={s.id}
            href={`/${s.assistant}?session=${s.id}`}
            className="card card-hover flex gap-3 items-start"
          >
            <span className="text-xl mt-0.5">{meta?.icon}</span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className={`text-xs font-semibold ${meta?.color}`}>{meta?.label}</span>
                {s.status === "completed" && (
                  <span className="badge bg-green-100 text-green-700">concluído</span>
                )}
              </div>
              <div className="font-medium text-sm truncate">{s.title}</div>
              <div className="text-xs text-compass-muted">{date}</div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}
