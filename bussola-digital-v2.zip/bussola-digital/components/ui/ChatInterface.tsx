"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Image from "next/image";

interface Message {
  id?: string;
  role: "user" | "assistant";
  content: string;
}

interface ChatInterfaceProps {
  assistant: "clara" | "bia" | "caio" | "nina";
  title: string;
  subtitle: string;
  avatar: string;
  accentClass: string;
  placeholder: string;
  extraPayload?: Record<string, unknown>;
  sessionId?: string | null;
}

const avatarMap: Record<string, string> = {
  clara: "/avatars/clara-avatar.png",
  bia:   "/avatars/bia-avatar.png",
  caio:  "/avatars/caio-avatar.png",
  nina:  "/avatars/nina-avatar.png",
};

function parseMarkdown(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, "<code>$1</code>")
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*<\/li>\n?)+/gs, (m) => `<ul>${m}</ul>`)
    .replace(/\n{2,}/g, "</p><p>")
    .replace(/^(?!<[hul])(.+)$/gm, (m) => m.trim() ? m : "")
    .replace(/\n/g, "<br>");
}

export default function ChatInterface({
  assistant, title, subtitle, avatar, accentClass, placeholder, extraPayload, sessionId: propSessionId,
}: ChatInterfaceProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(propSessionId ?? searchParams.get("session"));
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const avatarSrc = avatar || avatarMap[assistant];

  // Carregar histórico se houver sessionId
  useEffect(() => {
    if (!sessionId) return;
    fetch(`/api/sessions/${sessionId}`)
      .then((r) => r.json())
      .then(({ messages: msgs }) => {
        if (Array.isArray(msgs)) setMessages(msgs);
      })
      .catch(() => {});
  }, [sessionId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 160)}px`;
    }
  }, [input]);

  async function handleSend() {
    const text = input.trim();
    if (!text || loading) return;

    setInput("");
    setError(null);
    const userMsg: Message = { role: "user", content: text };
    const updated = [...messages, userMsg];
    setMessages(updated);
    setLoading(true);

    try {
      // Criar sessão se ainda não existir
      let activeSessionId = sessionId;
      if (!activeSessionId) {
        const res = await fetch("/api/sessions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ assistant, title: text.slice(0, 60) }),
        });
        const { session } = await res.json();
        activeSessionId = session.id;
        setSessionId(activeSessionId);
        router.replace(`/${assistant}?session=${activeSessionId}`, { scroll: false });
      }

      // Salvar mensagem da aluna
      await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: [{ role: "user", content: text }], sessionId: activeSessionId }),
      });

      // Chamar o assistente
      const aiRes = await fetch(`/api/${assistant}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updated.map((m) => ({ role: m.role, content: m.content })),
          sessionId: activeSessionId,
          ...extraPayload,
        }),
      });

      if (!aiRes.ok) {
        const { error: errMsg } = await aiRes.json();
        throw new Error(errMsg ?? "Erro ao consultar o assistente");
      }

      const { content } = await aiRes.json();
      setMessages((prev) => [...prev, { role: "assistant", content }]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  async function handleExport() {
    if (messages.length === 0) return;
    const content = messages
      .map((m) => `${m.role === "user" ? "VOCÊ" : title.toUpperCase()}\n${m.content}`)
      .join("\n\n---\n\n");

    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bussola-${assistant}-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex flex-col h-[calc(100vh-7rem)]">
      {/* Header do assistente */}
      <div className="card mb-4 flex items-center justify-between py-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full overflow-hidden shrink-0">
            <Image src={avatarSrc} alt={title} width={40} height={40} className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="text-lg font-display font-bold leading-tight">{title}</h1>
            <p className={`text-xs font-medium ${accentClass}`}>{subtitle}</p>
          </div>
        </div>
        {messages.length > 0 && (
          <button onClick={handleExport} className="btn-ghost text-xs">
            Exportar
          </button>
        )}
      </div>

      {/* Área de mensagens */}
      <div className="flex-1 overflow-y-auto space-y-4 pb-4">
        {messages.length === 0 && (
          <div className="text-center py-12 text-compass-muted">
            <div className="w-20 h-20 rounded-full overflow-hidden mx-auto mb-3">
              <Image src={avatarSrc} alt={title} width={80} height={80} className="w-full h-full object-cover" />
            </div>
            <p className="text-sm">Comece digitando sua pergunta ou ideia abaixo.</p>
          </div>
        )}

        {messages.map((m, i) => (
          <div
            key={i}
            className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {m.role === "assistant" && (
              <div className="w-7 h-7 rounded-full overflow-hidden mr-2 mt-0.5 shrink-0">
                <Image src={avatarSrc} alt={title} width={28} height={28} className="w-full h-full object-cover" />
              </div>
            )}
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                m.role === "user"
                  ? "bg-compass-teal text-white rounded-tr-sm"
                  : "bg-white border border-compass-border rounded-tl-sm prose-compass"
              }`}
              dangerouslySetInnerHTML={
                m.role === "assistant"
                  ? { __html: parseMarkdown(m.content) }
                  : undefined
              }
            >
              {m.role === "user" ? m.content : undefined}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start">
            <div className="w-7 h-7 rounded-full overflow-hidden mr-2 shrink-0">
              <Image src={avatarSrc} alt={title} width={28} height={28} className="w-full h-full object-cover" />
            </div>
            <div className="bg-white border border-compass-border rounded-2xl rounded-tl-sm px-4 py-3">
              <div className="flex gap-1 items-center h-4">
                {[0, 1, 2].map((d) => (
                  <div
                    key={d}
                    className="w-2 h-2 rounded-full bg-compass-teal/40 animate-bounce"
                    style={{ animationDelay: `${d * 0.15}s` }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
            {error} — tente novamente ou recarregue a página.
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="card !p-3 flex gap-2 items-end">
        <textarea
          ref={textareaRef}
          className="flex-1 resize-none bg-transparent text-sm text-compass-navy placeholder:text-compass-muted focus:outline-none py-1.5 leading-relaxed min-h-[36px]"
          placeholder={placeholder}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={1}
          disabled={loading}
        />
        <button
          onClick={handleSend}
          disabled={loading || !input.trim()}
          className="btn-primary !py-2 !px-4 text-sm shrink-0"
        >
          Enviar
        </button>
      </div>
    </div>
  );
}
